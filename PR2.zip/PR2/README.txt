Ananth Durbha
CISC 642
PR2

Install all the requirements,  
	
PART 1

Then Run part1.ipynb with GPU to get the accuracy and if not run with cpu

It might take around 1 hour to run the code with GPU to get the Accuracy

The code will download the required dataset CIFAR100 then,

We get the accuracy for train and test 

PART 2

Then Run part2.ipynb and we get the Epoch from 1 to 30 with loss and validation accuracy

Then we get the testing accuracy of the best model

It takes around 2 hours to run the code and get the Accuracy of the best model

PART 3

We import the required libraries

After that load FCN-Resnet101

Then we give some input images

The input images are  saved in file named images_cifar

Finally, we get the Segmentation and Feature maps.